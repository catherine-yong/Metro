#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

typedef struct maillon 
{
    float c;
    int n;
    struct maillon *suivant;

}maillon;

maillon *create_node(float c_cree, int n_cree)
{
    /* on crée un maillon */
    maillon *element;
    element = (maillon *) malloc(sizeof(maillon));
    element->c = c_cree;
    element->n = n_cree;
    element->suivant = NULL;
    return element;
}

maillon *add_node_sorted(maillon *head, float c_cree, int n_cree)
{
    /* on veut ajouter un maillon à la liste chainée de sorte a ce que la liste de retour soit triee */
    maillon *current = head;
    maillon *new_node = create_node(c_cree, n_cree);

    /* si la tete est vide ou si l'element a inserer a un n plus grand que le n de la tete, alors on insere le nouvel element au debut */

    if ((head == NULL) || ((head)->n < new_node->n)) 
    {
        new_node->suivant = head;
        head = new_node;
    } 
    
    /* si on veut inserer l'element au milieu ou tout a la fin alors on parcourt jusqu'au bon rang de n
     c'est a dire une fois que le n du nouvel element est plus petit que le n du maillon courant ou quand on est arrive a la fin */

    else 
    {
        while (current->suivant != NULL && current->suivant->n >= new_node->n) {
            current = current->suivant;
        }
        if (current->n == new_node->n) 
        {    
            /* exercice 4 : on traite le cas ou n existe deja dans la liste */
            current->c += c_cree;
            free(new_node);
        } 
        else 
        {
            new_node->suivant = current->suivant;
            current->suivant = new_node;
        }
    }
    return head;
}


void print_list(maillon *head)
{
    /* on affiche la liste chainee */

    while(head)
    {
        printf("c : %.2f  n : %d\n",head->c,head->n);
        head = head->suivant;
    } 
    printf("\n");
}

maillon *delete_head(maillon *head)
{
    /* on supprime la tete de la liste et on retourne la liste qui reste */
    /* node_delete pointe sur la tete */
    maillon *node_delete = head->suivant;

    if (!head)
    {
        return NULL;
    }
    
    /* on libere le contenu de la tete */
    free(head);
    return node_delete;
}


maillon *init_list()
{
    maillon *head = NULL;
    int n = 0;
    float c = 0.00;
    int el = 1;

    do {
        printf("element %d\n",el);
        el++;
        printf("valeur de c : ");
        scanf("%f", &c);
        printf("valeur de n : ");
        scanf("%d", &n);
        printf("\n\n");
        if (n >= 0)
        {
            head = add_node_sorted(head,c,n);
        }
    } while (n >= 0);


    return head;
}

float value_polynomial(maillon *polynomial, float x)
{
    float somme = 0.0;
    maillon *pointeur = polynomial;

    while(pointeur != NULL)
    {
        somme += (pointeur->c)*pow(x,pointeur->n);
        pointeur = pointeur->suivant;
    }
    
    return somme;
}

maillon *add_polynomial(maillon *polynomial1, maillon *polynomial2)
{
    maillon *p1 = NULL;
    p1 = polynomial1;
    maillon *p2 = NULL;
    p2 = polynomial2;
    maillon *result = NULL;
    
    /* tant que l'un des deux polynomes n'est pas fini, on ajoute soit p1 soit p2. 
    le tri des valeurs de n est automatique car realise dans la fonction add_node_result */

    while(p1 != NULL || p2 != NULL)
    {
        if(p1->n )
        {
            result = add_node_sorted(result, p1->c, p1->n);
            p1 = p1->suivant;
        }

        if(p2 != NULL)
        {
            result = add_node_sorted(result, p2->c, p2->n);
            p2 = p2->suivant;
        }
    }   

    return result;
}

maillon *multiplication_reelle(maillon *polynome, float a)
{
    maillon *pointeur;
    pointeur = polynome;

    while(pointeur != NULL)
    {
        pointeur->c = a*pointeur->c;
        pointeur = pointeur->suivant;
    }

    return polynome;
}

maillon *multiplication_monome(maillon *polynome, float c_mult, int n_mult)
{
    maillon *pointeur;
    pointeur = polynome;

    while(pointeur != NULL)
    {
        pointeur->c = c_mult*pointeur->c;   /* produit des coefficients */
        pointeur->n = n_mult+pointeur->n;   /* somme des puissances */
        pointeur = pointeur->suivant;
    }

    return polynome;
}

int main()
{    
    int n_cree = 0;
    float c_cree = 0, x = 0;
    maillon *polynome1 = NULL;
    maillon *polynome2 = NULL;
    maillon *result = NULL;
    maillon *head = NULL;

    printf("soit la liste chaînée suivante.\n");
    head = add_node_sorted(head,1,1);
    head = add_node_sorted(head,3,2);
    head = add_node_sorted(head,9,8);
    head = add_node_sorted(head,5,3);
    head = add_node_sorted(head,2,10);
    print_list(head);

    printf("\nnous allons ajouter un élément. choisissez le coefficient réel c de l'élément à ajouter\n");
    scanf("%f",&c_cree);
    printf("\nchoisissez le coefficient entier n de l'élément à ajouter\n");
    scanf("%d",&n_cree);
    head = add_node_sorted(head,c_cree,n_cree);
    print_list(head);
    
    printf("\nsupprimons la tete de cette liste. resultat : \n");
    head = delete_head(head);
    print_list(head);

    printf("\nnous allons initialiser une liste\n");
    polynome1 = init_list();
    print_list(polynome1);
    
    printf("\nnous allons calculer la valeur du polynome défini au-dessus pour un x particulier\nchoisir la valeur de x\n");
    scanf("%f",&x);
    printf("la valeur du polynome pour x=%.2f vaut %.2f\n",x,value_polynomial(polynome1,x));
    
    printf("\nsoit notre deuxième polynome :\n");
    polynome2 = init_list();
    print_list(polynome2);

    printf("\nnous allons calculer la somme de ces 2 polynomes\n");
    result = add_polynomial(polynome1,polynome2);
    print_list(result);
    
    printf("\nnous allons calculer le produit du polynome 1 avec un reel. choisir la valeur de ce reel\n");
    scanf("%f",&x);
    polynome1 = multiplication_reelle(polynome1,x);
    print_list(polynome1);
    
    printf("\nnous allons calculer le produit du polynome2 par une constante c.x^n. choisir la valeur de c\n");
    scanf("%f",&c_cree);
    printf("\nchoisir la valeur de n\n");
    scanf("%d",&n_cree);
    polynome2 = multiplication_monome(polynome2,c_cree,n_cree);
    print_list(polynome2);
    
    return 0;

}